#define _CRT_SECURE_NO_WARNINGS
#include <stddef.h>
#include <cstddef> // for std::nullptr_t
#include <cstdio>

#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <cstdio>

#include <cassert>
#include <time.h>

#include <stdarg.h>
//#include <utility>
//#include <vector>
#include <stdexcept>


#include <cmath>